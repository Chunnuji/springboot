package com.example.SpringSecurityLearn_2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecurityLearn2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringSecurityLearn2Application.class, args);
	}

}
