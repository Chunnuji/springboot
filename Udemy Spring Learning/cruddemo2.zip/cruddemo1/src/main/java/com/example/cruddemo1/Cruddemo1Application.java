package com.example.cruddemo1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Cruddemo1Application {

	public static void main(String[] args) {
		SpringApplication.run(Cruddemo1Application.class, args);
	}

}
