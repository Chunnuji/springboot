package com.example.qualifier;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QualifierApplicationTests {

	@Test
	void contextLoads() {
	}

}
